/* ════════════════════════════════════════════════════════════════════════════
   SDT SITE SHELL — builds the three menus on every page.
   J. C. Harvey, Melbourne.  Pairs with sdt-shell.css.

     LEFT vertical column  — Navigation
     RIGHT vertical column — Scrollers
     TOP bar               — Settings
   ════════════════════════════════════════════════════════════════════════════ */
(function () {
  'use strict';
  if (window.__SDT_SHELL__) return;
  window.__SDT_SHELL__ = true;

  var here = (location.pathname.split('/').pop() || 'index.html').toLowerCase();
  var onAtlas = (here === 'index.html' || here === '' || here === 'atlas.html');

  /* section anchors live on the atlas; from any other page, jump back to it */
  function sec(hash) { return onAtlas ? ('#' + hash) : ('index.html#' + hash); }

  /* ── LEFT COLUMN — Navigation ─────────────────────────────────────────── */
  var NAV = [
    ['The framework', [
      ['The Medium',   sec('medium')],
      ['Six Laws',     sec('laws')],
      ['Topology',     sec('topology')],
      ['Atomicus',     sec('atomicus')],
      ['Lab',          sec('lab')],
      ['Engine',       sec('engine')],
      ['Cosmology',    sec('cosmology')],
      ['Experiments',  sec('experiments')],
      ['Glossary',     sec('glossary')]
    ]],
    ['Read', [
      ['Atlas — home',  'index.html'],
      ['Welcome',       'welcome.html'],
      ['Causal chain',  'causal-chain.html'],
      ['What we assume','inputs.html'],
      ['Predictions',   'experiments.html'],
      ['Investigations','investigations.html'],
      ['Benchmarks',    'benchmarks.html']
    ]],
    ['Domain papers', [
      ['01 · Foundations',        'paper-01-foundations.html'],
      ['02 · Particle topology',  'paper-02-particle-topology.html'],
      ['03 · Electromagnetism',   'paper-03-electromagnetism.html'],
      ['04 · Atomic spectroscopy','paper-04-atomic-spectroscopy.html'],
      ['05 · Nuclear',            'paper-05-nuclear.html'],
      ['06 · Gravitation',        'paper-06-gravitation.html'],
      ['07 · Cosmology',          'paper-07-cosmology.html'],
      ['08 · Galactic',           'paper-08-galactic.html'],
      ['09 · Stellar',            'paper-09-stellar.html'],
      ['10 · Fluid',              'paper-10-fluid.html'],
      ['11 · Thermodynamics',     'paper-11-thermodynamics.html'],
      ['12 · Condensed matter',   'paper-12-condensed-matter.html'],
      ['13 · Quantum foundations','paper-13-quantum-foundations.html'],
      ['14 · Plasma & magnetism', 'paper-14-plasma-magnetism.html'],
      ['15 · Optics',             'paper-15-optics.html'],
      ['16 · Chemistry',          'paper-16-chemistry.html']
    ]]
  ];

  /* ── RIGHT COLUMN — Scrollers ─────────────────────────────────────────── */
  var SCR = [
    ['Scrollthroughs', [
      ['SDT walkthrough',  'sdt_walkthrough.html'],
      ['The six laws',     'laws_scroller.html'],
      ['Benchmarks',       'benchmarks_scroller.html'],
      ['Depth closure',    'depth_closure_scroller.html'],
      ['Eclipse',          'cq06-eclipse.html']
    ]],
    ['Teaching sequence', [
      ['00 · Primitives',  'st_00_primitives.html'],
      ['01 · Law I',       'st_01_law1.html'],
      ['02 · Law II',      'st_02_law2.html'],
      ['03 · Law III',     'st_03_law3.html'],
      ['04 · Law IV',      'st_04_law4.html'],
      ['Lattice',          'st_flm01.html'],
      ['Gravity',          'st_gom_gravity.html'],
      ['Magic numbers',    'st_magic_numbers.html']
    ]],
    ['Investigation scrollers', [
      ['FLM01 · force ratios',      'flm01_scroller.html'],
      ['FLM02 · pulse mechanics',   'flm02_scroller.html'],
      ['PPT01 · vortex equilibrium','ppt01_scroller.html'],
      ['PPT02 · fine structure',    'ppt02_scroller.html'],
      ['PPT04 · neutrino moment',   'ppt04_scroller.html'],
      ['PPT05 · trefoil',           'ppt05_scroller.html'],
      ['PPT06 · spation traction',  'ppt06_scroller.html'],
      ['EMC01 · transfer function', 'emc01_scroller.html'],
      ['APS01 · emissions',         'aps01_scroller.html'],
      ['APS02 · emission prediction','aps02_scroller.html']
    ]],
    ['Sequencer', [
      ['Nuclear packing sequencer', 'nuclear-packing-sequencer.html'],
      ['Sequencer walkthrough',     'nuclear-packing-walkthrough.html'],
      ['Construction zone',         'atomicus-construction-zone.html']
    ]],
    ['The lab', [
      ['Atomicus lab',        'atomicus-lab.html'],
      ['Lab · tiers (v4)',    'atomicus-lab-v4-tiers.html'],
      ['Nuclear model',       'atomicus-nuclear-model.html'],
      ['Traction assembly',   'atomicus-stick.html'],
      ['Traction · polar caps','atomicus-stick-v3-polar-caps.html'],
      ['Fission impact',      'atomicus-fission-impact.html'],
      ['Monoisotopic morph',  'monoisotopic-morph.html'],
      ['v1 snapshot',         'atomicus-v1-snapshot.html']
    ]]
  ];

  /* ── helpers ──────────────────────────────────────────────────────────── */
  function el(tag, cls, html) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (html != null) n.innerHTML = html;
    return n;
  }

  function column(title, groups, side) {
    var c = el('nav', 'sdtq-column sdtq-' + side);
    c.setAttribute('aria-label', title);

    var x = el('button', 'sdtq-close', '&times;');
    x.type = 'button';
    x.setAttribute('aria-label', 'Close ' + title);
    x.addEventListener('click', closeAll);
    c.appendChild(x);

    c.appendChild(el('h2', null, title));
    groups.forEach(function (g) {
      c.appendChild(el('h3', null, g[0]));
      g[1].forEach(function (item) {
        var a = el('a', null, item[0]);
        a.href = item[1];
        if (item[1].toLowerCase() === here) a.setAttribute('aria-current', 'page');
        c.appendChild(a);
      });
    });
    return c;
  }

  /* ── settings ─────────────────────────────────────────────────────────── */
  var store = {
    get: function (k, d) { try { return localStorage.getItem('sdt.' + k) || d; } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem('sdt.' + k, v); } catch (e) {} }
  };
  var APPLY = {
    theme: function (v) {
      var t = v === 'auto'
        ? (window.matchMedia && window.matchMedia('(prefers-color-scheme:dark)').matches ? 'dark' : 'light')
        : v;
      document.documentElement.setAttribute('data-theme', t);
      document.documentElement.setAttribute('data-sdt-theme', t);
    },
    text: function (v) {
      document.documentElement.style.fontSize = ({ s: '93.75%', m: '', l: '112.5%' })[v] || '';
    },
    motion: function (v) { document.documentElement.setAttribute('data-sdt-motion', v); }
  };
  var OPTS = {
    theme:  [['Auto', 'auto'], ['Light', 'light'], ['Dark', 'dark']],
    text:   [['S', 's'], ['M', 'm'], ['L', 'l']],
    motion: [['On', 'on'], ['Off', 'off']]
  };
  var DEFAULT = { theme: 'auto', text: 'm', motion: 'on' };

  function sync(key) {
    var cur = store.get(key, DEFAULT[key]);
    document.querySelectorAll('.sdtq-seg[data-key="' + key + '"] button').forEach(function (b) {
      b.setAttribute('aria-pressed', String(b.getAttribute('data-val') === cur));
    });
  }

  function settings() {
    var wrap = el('div', 'sdtq-settings');
    ['theme', 'text', 'motion'].forEach(function (key) {
      var lab = el('label', null, '<span>' + key.charAt(0).toUpperCase() + key.slice(1) + '</span>');
      var seg = el('span', 'sdtq-seg');
      seg.setAttribute('data-key', key);
      OPTS[key].forEach(function (o) {
        var b = el('button', null, o[0]);
        b.type = 'button';
        b.setAttribute('data-val', o[1]);
        b.addEventListener('click', function () {
          store.set(key, o[1]);
          APPLY[key](o[1]);
          sync(key);
        });
        seg.appendChild(b);
      });
      lab.appendChild(seg);
      wrap.appendChild(lab);
    });
    return wrap;
  }

  /* ── open / close ─────────────────────────────────────────────────────── */
  var panels = {}, openKey = null;
  function closeAll() {
    openKey = null;
    Object.keys(panels).forEach(function (k) { panels[k].classList.remove('sdtq-open'); });
    document.querySelectorAll('[data-sdtq-target]').forEach(function (b) {
      b.setAttribute('aria-expanded', 'false');
    });
  }
  function toggle(key) {
    var wasOpen = (openKey === key);
    closeAll();
    if (wasOpen) return;
    openKey = key;
    panels[key].classList.add('sdtq-open');
    document.querySelectorAll('[data-sdtq-target="' + key + '"]').forEach(function (b) {
      b.setAttribute('aria-expanded', 'true');
    });
  }

  /* ── build ────────────────────────────────────────────────────────────── */
  function boot() {
    ['theme', 'text', 'motion'].forEach(function (k) { APPLY[k](store.get(k, DEFAULT[k])); });

    var root = el('div', 'sdtq');
    var bar = el('div', 'sdtq-bar');
    bar.appendChild(el('div', 'sdtq-brand',
      '<a href="index.html">S<span>.</span>D<span>.</span>T<span>.</span></a>'));
    bar.appendChild(settings());

    var left = column('Navigation', NAV, 'left');
    var right = column('Scrollers', SCR, 'right');
    var setPanel = el('div', 'sdtq-panel');
    setPanel.appendChild(settings());
    panels = { nav: left, set: setPanel, scr: right };

    var tabs = el('div', 'sdtq-tabs');
    var burgers = el('div', 'sdtq-burgers');
    [['nav', 'Navigation'], ['set', 'Settings'], ['scr', 'Scrollers']].forEach(function (d) {
      var b = el('button', null, d[1]);
      b.type = 'button';
      b.setAttribute('data-sdtq-target', d[0]);
      b.setAttribute('aria-expanded', 'false');
      b.addEventListener('click', function (e) { e.stopPropagation(); toggle(d[0]); });
      tabs.appendChild(b);

      var h = el('button', null, '<i></i><i></i><i></i>');
      h.type = 'button';
      h.setAttribute('data-sdtq-target', d[0]);
      h.setAttribute('aria-expanded', 'false');
      h.setAttribute('aria-label', d[1]);
      h.title = d[1];
      h.addEventListener('click', function (e) { e.stopPropagation(); toggle(d[0]); });
      burgers.appendChild(h);
    });

    bar.appendChild(tabs);
    bar.appendChild(burgers);

    root.appendChild(bar);
    root.appendChild(left);
    root.appendChild(right);
    root.appendChild(setPanel);
    document.body.appendChild(root);

    ['theme', 'text', 'motion'].forEach(sync);

    document.addEventListener('click', function (e) {
      if (openKey && !root.contains(e.target)) closeAll();
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') closeAll();
    });
    /* close the flyout after following a link on small screens */
    root.addEventListener('click', function (e) {
      if (e.target.tagName === 'A' && openKey) closeAll();
    });

    if (window.matchMedia) {
      var mq = window.matchMedia('(prefers-color-scheme:dark)');
      var onChange = function () { if (store.get('theme', 'auto') === 'auto') APPLY.theme('auto'); };
      mq.addEventListener ? mq.addEventListener('change', onChange)
                          : (mq.addListener && mq.addListener(onChange));
    }

    /* highlight the atlas section currently in view */
    if (onAtlas && 'IntersectionObserver' in window) {
      var ids = ['medium', 'laws', 'topology', 'atomicus', 'lab', 'engine', 'cosmology', 'experiments', 'glossary'];
      var links = {};
      ids.forEach(function (id) {
        var a = left.querySelector('a[href="#' + id + '"]');
        if (a) links[id] = a;
      });
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
          if (!en.isIntersecting) return;
          Object.keys(links).forEach(function (k) { links[k].classList.remove('sdtq-active'); });
          if (links[en.target.id]) links[en.target.id].classList.add('sdtq-active');
        });
      }, { rootMargin: '-45% 0px -50% 0px' });
      ids.forEach(function (id) {
        var s = document.getElementById(id);
        if (s) io.observe(s);
      });
    }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
